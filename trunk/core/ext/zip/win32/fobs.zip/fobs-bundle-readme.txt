Extracted from : fobs4jmf_0.4.1_win32.zip
On date        : Fri Apr 13 18:03:50 PDT 2007
